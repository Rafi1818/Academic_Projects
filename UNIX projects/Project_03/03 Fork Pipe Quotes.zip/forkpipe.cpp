#include <stdlib.h>
#include <string.h>
#include <cstdlib>
#include <cstring>
#include <unistd.h>
#include <stdio.h>
#include <iostream>
#include <sys/types.h>
#include <time.h>

#include "LineInfo.h"

using namespace std;

static const char* const QUOTES_FILE_NAME = "quotes.txt";

int const READ   = 0;
int const WRITE  = 1;
int const PIPE_ERROR = -1;
int const FORK_ERROR = -1;
int const CHILD_PID  =  0;
int const MAX_PIPE_MESSAGE_SIZE = 1000;
int const MAX_QUOTE_LINE_SIZE   = 1000;


void getQuotesArray(char *lines[], unsigned &noLines){

}

void executeParentProcess(int pipeParentWriteChildReadfds[], int pipeParentReadChildWritefds[], int noOfParentMessages2Send) {

}

void executeChildProcess(int pipeParentWriteChildReadfds[], int pipeParentReadChildWritefds[], char* lines[], unsigned noLines) {

}

int main(int argc, char* argv[]) {

 try {
   if (argc != 2)
       throw domain_error(LineInfo("Usage: ./forkpipe <number>", __FILE__, __LINE__));
    
   //argv[0] is the program name, argv[1] is the number, atoi = ascii to int
   int      noOfParentMessages2Send = atoi(argv[1]);
   char     *lines[1000];
   unsigned noLines;
  
   getQuotesArray(lines, noLines);
    
   int pipeParentWriteChildReadfds[2], 
       pipeParentReadChildWritefds[2];
   int pid;
    
   // create pipes    
   if (pipe(pipeParentWriteChildReadfds) == PIPE_ERROR)
     throw domain_error(LineInfo("Unable to create pipe pipeParentWriteChildReadfds", __FILE__, __LINE__));

   if (pipe(pipeParentReadChildWritefds) == PIPE_ERROR)
     throw domain_error(LineInfo("Unable to create pipe pipeParentReadChildWritefds", __FILE__, __LINE__));
   
   cout << endl <<endl;

   pid = fork();

   if      (pid == FORK_ERROR)
       throw domain_error(LineInfo("Fork Error", __FILE__, __LINE__));

   else if (pid != CHILD_PID) {
      // Parent process
      executeParentProcess(pipeParentWriteChildReadfds, pipeParentReadChildWritefds, noOfParentMessages2Send);
    }
   else { 
      //child process
      executeChildProcess(pipeParentWriteChildReadfds, pipeParentReadChildWritefds, lines, noLines);
   }
 }//try
 catch (exception& e) {
    cout << e.what() << endl;
    cout << endl << "Press the enter key once or twice to leave..." << endl;
    cin.ignore(); cin.get();
    exit(EXIT_FAILURE);
 }//catch

exit (EXIT_SUCCESS);

}
